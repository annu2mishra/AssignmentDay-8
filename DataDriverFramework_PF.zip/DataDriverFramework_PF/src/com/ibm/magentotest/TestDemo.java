package com.ibm.magentotest;

import org.testng.annotations.*;

public class TestDemo {

				
			@Test
			public void bTest()
			{
				System.out.println("Before Test");
			}
			
			@Test
			public void aTest()
			{
				System.out.println("After Test");
			}
			@BeforeMethod
			public void bMethod()
			{
				System.out.println("bMethod");
			}
			
			@AfterMethod
			public void aMethod()
			{
				System.out.println("aMethod");
			}
}

