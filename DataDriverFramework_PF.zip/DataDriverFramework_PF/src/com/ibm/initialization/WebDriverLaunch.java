package com.ibm.initialization;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.ibm.utilities.PropertiesFileHandler;

public class WebDriverLaunch {
	
	public WebDriver driver;
	public WebDriverWait wait;
	public PropertiesFileHandler propFileHandler;
	public HashMap<String, String> data;
	
	@BeforeSuite
	public void preSetForTest() throws IOException
	{
		String file="./TestData/magentodata.properties";
		
		//Location //Properties handler
		propFileHandler = new PropertiesFileHandler();
		data= propFileHandler.getPropertiesAsMap(file);
	}
	
	
	@BeforeMethod
	@Parameters({"browser"})
	public void intialization()
	{
			
		wait=new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);	
		
	}
	
	@AfterMethod
	public void closeBrowser()
	{
		driver.quit();
	}

	public void browserInitialization(String browser)
	{
		switch(browser.toLowerCase()) {
		case "ff":
			System.setProperty("webdriver.gecko.driver", "./firefox.exe");
			driver = new FirefoxDriver();
			break;
		case "ch":
			System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");
			driver = new ChromeDriver();
			break;
		case "ie":
			System.setProperty("webdriver.ie.driver", "./IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			break;
		default:
			System.out.println("No browser Available"+browser);
			break;
		
		}
	}
}
