package com.ibm.magentopages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {
	
	@FindBy(id="email")
	WebElement emailEle;
	
	@FindBy(how=How.ID,using="pass")
	WebElement passEle;
	
	@FindBy(xpath="//button[@type='submit']")
	WebElement loginEle;
	
	By errMsgLoc=By.className("error-msg");
	
	@FindBy(xpath="//a[@href=\"https://account.magento.com/customer/account/forgotpassword/\"]")
	WebElement forgotPassword;
	
		
	@FindBy(xpath="//input[@id='email_address']")
	WebElement enterEmail;
	
	@FindBy(xpath="//span[text()='Submit']")
	WebElement submitButton;
	
	By requiredErrorMsg=By.className("validation-advice");
	
	By entrValidEmailAdd=By.className("validation-advice");
	
	WebDriverWait wait;
	WebDriver driver;
	
	public LoginPage(WebDriver driver, WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
	}

	public void enterEmailAddress(String userName)
	{
		emailEle.sendKeys(userName);
	}
	
	public void enterPassword(String password)
	{
		passEle.sendKeys(password);
	}
	
	public void clickOnLogin()
	{
		loginEle.click();
	}
	
	public String getPageSourceforInvalidErrorMessage()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(errMsgLoc));
		
		return driver.getPageSource();
	}
	public void forgotPassword()
	{
		forgotPassword.click();
	}
	
	public void enterEmail(String reenteremailaddress)
	{
		enterEmail.sendKeys(reenteremailaddress);
	}
	public void submitButton()
	{
		submitButton.click();
	}
	public String requiredFieldErrorMessage()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(requiredErrorMsg));
		
		return driver.getPageSource();
	}
	public String getPageSourceToEnterValidEmailErrorMessage()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(entrValidEmailAdd));
		
		return driver.getPageSource();
	}
}
